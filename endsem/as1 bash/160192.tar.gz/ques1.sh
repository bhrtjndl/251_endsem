#!/bin/bash

#while first is zero skip
#while not at end store and increment i from to check length
#print result accordingly

function ones(){
	if [[ $1 -eq 0 ]]; then
		exit
	fi
	if [[ $1 -ge 20 ]]; then
		local num=$(($1/10))
		#local ten=`echo $str3 | cut -d " " -f$num`
		#echo "$ten"| tr "\n" " "
		echo $str3 | cut -d " " -f$num | tr "\n" " "

		local one=$(($1%10))
		ones $one

	elif [[ $1 -ge 10 ]]; then
		#local ten=`echo $str2 | cut -d " " -f$(($num-9))`
		#echo "$ten"| tr "\n" " "
		echo $str2 | cut -d " " -f$(($1-9)) | tr "\n" " "

	elif [[ $1 -gt 0 ]]; then
		#local one=`echo $str1 | cut -d " " -f$num`
		#echo "$one"| tr "\n" " "
		echo $str1 | cut -d " " -f$1 | tr "\n" " "
	fi

}

function hundreds(){
	if [[ $1 -eq 0 ]]; then
		exit
	fi
	local hund=$(($1/100))
	if [[ $hund -ne 0 ]]; then
		ones $hund
		echo "hundred" | tr "\n" " "
	fi
	ones $(($1%100))

}

function thousands(){
	if [[ $1 -eq 0 ]]; then
		exit
	fi
	local thd=$(($1/1000))
	if [[ $thd -ne 0 ]]; then
		ones $thd
		echo "thousand" | tr "\n" " "
	fi
	hundreds $(($1%1000))
}

function lakhs(){
	if [[ $1 -eq 0 ]]; then
		exit
	fi
	local lkh=$(($1/100000))
	if [[ $lkh -ne 0 ]]; then
		#statements
		ones $lkh
		echo "lakh" | tr "\n" " "
	fi
	thousands $(($1%100000))
}

function crores(){
	if [[ $1 -eq 0 ]]; then
		exit
	fi
	local crr=$(($1/10000000))
	if [[ $crr -ne 0 ]]; then
		#statements
		thousands $crr
		printf "crore "
	fi
	lakhs $(($1%10000000))
}

str1="one two three four five six seven eight nine"
str2="ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen"
str3="null twenty thirty fourty fifty sixty seventy eighty ninty"

echo "Enter the number"
read a

#negative numbers and zero ka kro jugaad!
if [[ $a -eq 0 ]]; then
	#statements
	echo zero
	exit
fi
a=$(echo $a | sed 's/^0*//')
len=$(echo $a | wc -m)
len=$(($len-1))
if [ $len -gt 11 ] || [ $len -lt 1 ]; then
	echo invalid input
fi
crores $a

exit;