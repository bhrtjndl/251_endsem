#!/bin/bash

##Code working properly in portions
##giving correct reex expression answers
## not working on whole


regex_it(){
	#f_sent regex giving sentences
	#f_num regex giving numbers
	total_num=$(cat $1 | grep -E -o '[0-9]+([0-9]+)*(\.[0-9]+([0-9]+)?)?' | wc -l)
	decimal_num=$(cat $1 | grep -E -o '[0-9]+([0-9]+)*(\.[0-9]+([0-9]+)?)' | wc -l)
	local f_sent=$(cat $1 | grep -E -o '[A-Za-z][^\.!?]*[\.!?]' $1 | wc -l)
	local f_num=$(($total_num-$decimal_num))
	echo $f_sent $f_num
}


go_deep(){
	#depth as parameter
	depth=$1
	local num=0
	local sent=0
	#num=0,sent=0
	#for all files/dir

	for i in * ; do

				
		if [[ -d "$i" ]]; then
			cd $i

			#catching echo of sent and num
			t=$( go_deep $(($depth+1)) )
			f_sent=`echo $t|cut -d " " -f1`
			f_num=`echo $t|cut -d " " -f2`

			num=$(($num + $f_num))
			sent=$(($sent + $f_sent))
			cd ..

			for (( k = 0; k < $depth; k++ )); do
				#echo| tr "\n" "\t"
				printf "\t"
			done
			
			local print="(D) $i-$f_sent-$f_num"
			printf "%s\n" "$print"
		fi

		if [[ -f "$i" ]]; then
			#statements
			for (( j = 0; j <= $depth; j++ )); do
				#echo| tr "\n" "\t"
				printf "\t"
			done
			#catch f_sent
			#catch f_num
			t=$(regex_it $i)
			g_sent=`echo $t|cut -d " " -f1`
			g_num=`echo $t|cut -d " " -f2`

			sm="(F) $i-$g_sent-$g_num"
			printf "%s\n" "$sm"
			num=$(($num + $g_num))
			sent=$(($sent + g_sent))
		fi
	done
		
		
	echo $sent $num
}
main_dir=$1
cd $main_dir

res=$(go_deep 0)
sent=`echo $res|cut -d " " -f1`
num=`echo $res|cut -d " " -f2`

echo "$main_dir-$sent-$num"
