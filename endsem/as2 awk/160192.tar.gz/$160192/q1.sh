#!/bin/bash

cmnts=0
strngs=0

recurse(){
     cd "$1"
     for line in *
     do
           if [ -d "$line" ];
           then
                recurse "$line"
                 
           fi
     done
     for line in *
     do
           if [ -f "$line" ]
           then
                regex='\.c$'
                
                if [[ "$line" =~ $regex ]]
                then   
                   read res <<< $( awk -f ~/q1.awk "$PWD/$line" )
                   cmnt=$(echo $res | cut -d " " -f1)
                   strng=$(echo $res | cut -d " " -f2)
                   cmnts=$(($cmnt+$cmnts))
                   strngs=$(($strng+$strngs))
                fi
           fi
     done
     cd ..   
}

recurse "$1"
echo Total comments,all c files $cmnts
echo Total Strings, all c files $strngs

